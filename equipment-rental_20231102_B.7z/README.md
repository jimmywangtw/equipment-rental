# equipment-rental
npm start after opening server at backend-server
